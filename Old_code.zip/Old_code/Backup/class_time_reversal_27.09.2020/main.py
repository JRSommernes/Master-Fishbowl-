import numpy as np
from time_reversal import *
from constants import *
import matplotlib.pyplot as plt

def reconstruct_image():
    microscope = Microscope(N_sensors)

    microscope.make_sensors(sensor_radius)
    microscope.make_dipoles(dipole_pos,polarization)
    microscope.reconstruct_image(N_reconstruction)

    

dipole_pos = np.array([[-0.3*lambda_0,0.7*lambda_0,0],[0.7*lambda_0,0.7*lambda_0,0]])
polarization = np.array([[1,0,0],[0,0,1]])

reconstruct_image()

# plt.imshow(microscope.I[:,:,N_reconstruction//2],extent=(-FoV/2,FoV/2,FoV/2,-FoV/2))
# plt.xlabel('x')
# plt.ylabel('y')
# plt.colorbar()
# for dipole in microscope.dipoles:
#     plt.scatter(dipole.x,dipole.y,color='r')
# plt.show()
