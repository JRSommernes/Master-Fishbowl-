from numba import jit
import numpy as np
import matplotlib.pyplot as plt
import sympy as syp
from PIL import Image

def process_image(im):
    im = np.nan_to_num(im,nan=np.max(np.nan_to_num(im,nan=0)))
    im = im - np.min(im)
    im = im/np.max(im)
    im = im/np.max(im)
    return im

# @jit(nopython=False)
def dyadicgreens_integration(pos,save):
    #Defining variables x, y, and z
    x = syp.Symbol('x')
    y = syp.Symbol('y')
    z = syp.Symbol('z')
    k = syp.Symbol('k')

    #Defining a symbolic expression for the exponential function
    weight = syp.exp(1j*k*syp.sqrt(x**2+y**2+z**2))/(4*np.pi*k**2*syp.sqrt(x**2+y**2+z**2))

    #Using the exponential to derive the greens matrix
    greens_matrix = np.array([[k**2+weight.diff(x,x), weight.diff(x,y),weight.diff(x,z)],\
                    [weight.diff(y,x),k**2+weight.diff(y,y),weight.diff(y,z)],\
                    [weight.diff(z,x),weight.diff(z,y),k**2+weight.diff(z,z)]])

    wl = 0.690*10**-6 #Wavelength in microns
    k = 2*np.pi/wl #Wavenumber

    x_tmp = np.linspace(-5,5,101)
    y_tmp = np.linspace(-5,5,101)
    z_tmp = np.linspace(-5,5,101)

    xx,yy,zz = np.meshgrid(x_tmp,y_tmp,z_tmp) #Free space distance in x, y, and z measured in microns
    dist_x = xx - pos[0] #Finds distance in x direction
    dist_y = yy - pos[1] #Finds distance in y direction
    dist_z = zz - pos[2] #Finds distance in z direction
    # dist_r = np.sqrt(dist_x**2+dist_y**2+dist_y**2)


    print(greens_matrix[1,1], k**2)

    #Changing the greens matrix to a lambda function
    greens_matrix = syp.lambdify((x,y,z),greens_matrix)

    stop

    #Plugging in the distances in x, y, and z to find the numerical matrix
    G = np.flip(np.transpose(np.array(greens_matrix(dist_x,dist_y,dist_z)),(0,1,3,4,2)),(2,3))

    if save == True:
        print('Saving')
        for [greens,nr] in [[G[0,0],0.0],[G[0,1],0.1],[G[1,1],1.1],[G[0,2],0.2],[G[1,2],1.2],[G[2,2],2.2]]:
            shape = greens.shape
            for k in range(shape[2]):
                im = Image.fromarray(greens[:,:,k].real.astype(np.float64))
                im.save('integration/{}/offset_{}.tiff'.format(nr,k))

    return G


def dyadicgreens_algebraic(pos,save):
    wl = 0.690 #Wavelength in microns
    k = 2*np.pi/wl #Wavenumber
    N = 101
    FoV = 5

    x = np.linspace(-FoV,FoV,N)
    y = np.linspace(-FoV,FoV,N)
    z = np.linspace(-FoV,FoV,N)

    xx, yy, zz = np.meshgrid(x,y,z)
    r_x, r_y, r_z = xx-pos[0], yy-pos[1], zz-pos[2]

    r_p = np.array((r_x,r_y,r_z))

    R = np.sqrt(np.sum((r_p)**2,axis=0))
    R = np.where(R==0, 0.1, R)

    R_hat = ((r_p)/R)

    R_hat_tmp = R_hat.reshape(3,N**3).T
    RR_hat = np.einsum('ij,ik->ijk',R_hat_tmp,R_hat_tmp).reshape(N,N,N,3,3)

    g_R = np.exp(1j*k*R)/(4*np.pi*R)
    expr_1 = (3/(k**2*R**2)-3j/(k*R)-1)*g_R
    expr_2 = (1+1j/(k*R)-1/(k**2*R**2))*g_R

    I = np.identity(3)
    G = (expr_1[:,:,:,np.newaxis,np.newaxis]*RR_hat + expr_2[:,:,:,np.newaxis,np.newaxis]*I[np.newaxis,np.newaxis,np.newaxis]).T

    if save == True:
        print('Saving')
        for [greens,nr] in [[G[0,0],0.0],[G[0,1],0.1],[G[1,1],1.1],[G[0,2],0.2],[G[1,2],1.2],[G[2,2],2.2]]:
            shape = greens.shape
            for k in range(shape[2]):
                im = Image.fromarray(greens[:,:,k].real.astype(np.float64))
                im.save('algebraic/{}/offset_{}.tiff'.format(nr,k))

    return G


def main():
    for i in range(1):
        #Defining a position of an emitter
        position = np.array([-2,1,2])
        #Calling the function to find the greens matrix
        alge = dyadicgreens_algebraic(position,False)
        inte = dyadicgreens_integration(position,False)

        # tmp_1 = alge.real.astype(np.float64)
        # tmp_1 = process_image(tmp_1)
        # tmp_1 = tmp_1[0,0,:,:,60]
        #
        # tmp_2 = inte.real.astype(np.float64)
        # tmp_2 = process_image(tmp_2)
        # tmp_2 = tmp_2[0,0,:,:,60]
        #
        #
        # tmp = np.append(tmp_1,tmp_2,axis=1)
        # # tmp = tmp_2
        #
        #
        # plt.imshow(tmp)
        # plt.show()

main()


#Saving the greens matrix as a series of images
# shape = greens.shape
# for i in range(shape[0]):
#     for j in range(shape[1]):
#         for k in range(shape[4]):
#             real = Image.fromarray(greens[i,j,:,:,k].real.astype(np.float64))
#             imag = Image.fromarray(greens[i,j,:,:,k].imag.astype(np.float64))
#             real.save('greens_images/{}_{}/real/offset_{}.tiff'.format(i,j,k))
#             imag.save('greens_images/{}_{}/imag/offset_{}.tiff'.format(i,j,k))

#Saving the faster greens matrix as a series of images
# shape = greens.shape
# for k in range(shape[2]):
#     real = Image.fromarray(greens[:,:,k].real.astype(np.float64))
#     imag = Image.fromarray(greens[:,:,k].imag.astype(np.float64))
#     real.save('faster_greens_images/real/offset_{}.tiff'.format(k))
#     imag.save('faster_greens_images/imag/offset_{}.tiff'.format(k))


# shape = greens.shape
# for k in range(shape[2]):
#     im = Image.fromarray(greens[:,:,k].real.astype(np.float64))
#     im.save('test2/offset_{}.tiff'.format(k))


# fig = plt.figure()
# plt.imshow(greens_1[1,1,:,:,1].real)
# plt.draw()
# plt.waitforbuttonpress(0)
# plt.close(fig)
#
# fig = plt.figure()
# plt.imshow(greens_2[1,1,:,:,1].real)
# plt.draw()
# plt.waitforbuttonpress(0)
# plt.close(fig)
#
# fig = plt.figure()
# plt.imshow(superposition[1,1,:,:,1].real)
# plt.draw()
# plt.waitforbuttonpress(0)
# plt.close(fig)
