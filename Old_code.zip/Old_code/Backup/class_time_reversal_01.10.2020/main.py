import numpy as np
from time_reversal import *
from constants import *
import matplotlib.pyplot as plt
from PIL import Image
import os

def saveimage(I,dipole_pos,subdir,subsubdir):
    names = os.listdir('images')

    if subdir not in names:
        os.mkdir('images/'+subdir)

    os.chdir('images/'+subdir)

    names = os.listdir()

    if subsubdir not in names:
        os.mkdir(subsubdir)

    os.chdir(subsubdir)

    names = os.listdir()

    setup = '{}_dipoles__{}_sensors'.format(len(dipole_pos),N_sensors)

    if setup not in names:
        os.mkdir(setup)

    os.chdir(setup)
    dipoles = ''
    for i in range(len(dipole_pos)):
        dipoles += '[{0:.2f} {1:.2f} {2:.2f}]'.format(dipole_pos[i][0]/lambda_0,dipole_pos[i][1]/lambda_0,dipole_pos[i][2]/lambda_0)

    # dipole_1 = '[{0:.2f} {1:.2f} {2:.2f}]'.format(dipole_pos[0][0]/lambda_0,dipole_pos[0][1]/lambda_0,dipole_pos[0][2]/lambda_0)
    # dipole_2 = '[{0:.2f} {1:.2f} {2:.2f}]'.format(dipole_pos[1][0]/lambda_0,dipole_pos[1][1]/lambda_0,dipole_pos[1][2]/lambda_0)
    # dipoles = dipole_1+'__'+dipole_2

    names = os.listdir()
    if dipoles in names:
        print(dipoles+' already in directory')
        os.chdir('C:\python\Master (Fishbowl)\class_time_reversal')
        return
    else:
        os.mkdir(dipoles)

    for i in range(N_reconstruction):
        im = Image.fromarray(I[:,:,i].astype(np.float64))
        im.save(dipoles+'/{}.tiff'.format(i))

    plt.imshow(I[:,:,N_reconstruction//2],extent=(-FoV/2,FoV/2,FoV/2,-FoV/2))
    plt.xlabel('x')
    plt.ylabel('y')
    plt.colorbar()
    for dipole in dipole_pos:
        plt.scatter(dipole[0],dipole[1],color='r')
    plt.savefig(dipoles+'.tiff')
    plt.cla()   # Clear axis
    plt.clf()   # Clear figure

    os.chdir('C:\python\Master (Fishbowl)\class_time_reversal')

def reconstruct_image(pos,pol,subdir,subsubdir):
    microscope = Microscope(N_sensors)

    microscope.make_sensors(sensor_radius)
    microscope.make_dipoles(pos,pol)
    microscope.reconstruct_image(N_reconstruction)

    saveimage(microscope.I,pos,subdir,subsubdir)


# subdirect = ['Orthogonal_dipoles','Parallel_dipoles']
# polarization = np.array([[[1,0,0],[0,0,1]],[[1,0,0],[1,0,0]]])
# for i, pol in enumerate(polarization):
#     subdir = subdirect[i]
#
#     subsubdir = ['Symmetric_around_0', 'Symmetric_off_center']
#
#     for j in range(len(subsubdir)):
#         dist = np.linspace(0.2*lambda_0,1*lambda_0,16)
#         for num in dist:
#             x = num/2
#             dipole_pos = np.array([[-x,i*lambda_0,0],[x,i*lambda_0,0]])
#             reconstruct_image(dipole_pos,pol,subdir,subsubdir[j])

subdirect = ['Single dipole']
polarization = np.array([[[1,0,0]]])
for i, pol in enumerate(polarization):
    subdir = subdirect[i]

    subsubdir = ['FoV edge test, high resolution']

    for j in range(len(subsubdir)):
        r = np.linspace(3*lambda_0,5*lambda_0,3)
        for k in r:
            for l in r:
                dipole_pos = np.array([[k,l,0]])
                reconstruct_image(dipole_pos,pol,subdir,subsubdir[j])



# dipole_pos = np.array([[-0.3*lambda_0,0.7*lambda_0,0],[0.7*lambda_0,0.7*lambda_0,0]])
# polarization = np.array([[1,0,0],[0,0,1]])

# plt.imshow(microscope.I[:,:,N_reconstruction//2],extent=(-FoV/2,FoV/2,FoV/2,-FoV/2))
# plt.xlabel('x')
# plt.ylabel('y')
# plt.colorbar()
# for dipole in microscope.dipoles:
#     plt.scatter(dipole.x,dipole.y,color='r')
# plt.show()
