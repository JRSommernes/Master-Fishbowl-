import numpy as np
from scipy import constants
import matplotlib.pyplot as plt

def dyadicgreens(pos, FoV, N, lambda_0):
    """Short summary.

    Parameters
    ----------
    pos : type
        Description of parameter `pos`.

    Returns
    -------
    type
        Description of returned object.

    """
    eps_0 = 8.8541878128e-12
    mu_0 = 4*np.pi*10**-7
    c_0 = 1/np.sqrt(eps_0*mu_0)
    freq = c_0/lambda_0
    k_0 = 2*np.pi*freq*np.sqrt(eps_0*mu_0)
    omega = 2*np.pi*freq

    x = np.linspace(-FoV/2,FoV/2,N)
    y = np.linspace(-FoV/2,FoV/2,N)
    z = np.linspace(-FoV/2,FoV/2,N)

    xx, yy, zz = np.meshgrid(x,y,z)
    r_x, r_y, r_z = xx-pos[0], yy-pos[1], zz-pos[2]

    r_p = np.array((r_x,r_y,r_z))

    R = np.sqrt(np.sum((r_p)**2,axis=0))
    R = np.where(R==0, 0.1, R)

    R_hat = ((r_p)/R)


    R_hat_tmp = R_hat.reshape(3,N**3).T
    RR_hat = np.einsum('ij,ik->ijk',R_hat_tmp,R_hat_tmp).reshape(N,N,N,3,3)

    # g_R = np.exp(1j*(omega*t+k*R))/(4*np.pi*R)
    g_R = np.exp(1j*k_0*R)/(4*np.pi*R)
    expr_1 = (3/(k_0**2*R**2)-3j/(k_0*R)-1)*g_R
    expr_2 = (1+1j/(k_0*R)-1/(k_0**2*R**2))*g_R

    I = np.identity(3)
    G = (expr_1[:,:,:,np.newaxis,np.newaxis]*RR_hat + expr_2[:,:,:,np.newaxis,np.newaxis]*I[np.newaxis,np.newaxis,np.newaxis]).T

    ele = np.where(np.sqrt(xx**2+yy**2+zz**2)<lambda_0*0.2)
    ele = np.array([ele[0],ele[1],ele[2]]).T
    for el in ele:
        G[:,:,el[0],el[1],el[2]] = np.zeros((3,3))

    return G

def single_point_dyadicgreens(pos_dipole,pos_det,lambda_0):
    eps_0 = 8.8541878128e-12
    mu_0 = 4*np.pi*10**-7
    c_0 = 1/np.sqrt(eps_0*mu_0)
    freq = c_0/lambda_0
    k_0 = 2*np.pi*freq*np.sqrt(eps_0*mu_0)
    omega = 2*np.pi*freq

    x,y,z = pos_det
    r_x, r_y, r_z = x-pos_dipole[0], y-pos_dipole[1], z-pos_dipole[2]

    r_p = np.array((r_x,r_y,r_z))

    R = np.sqrt(np.sum((r_p)**2))
    R_hat = ((r_p)/R)

    RR_hat = R_hat.reshape(3,1).dot(R_hat.reshape(1,3))

    g_R = np.exp(1j*k_0*R)/(4*np.pi*R)
    expr_1 = (3/(k_0**2*R**2)-3j/(k_0*R)-1)*g_R
    expr_2 = (1+1j/(k_0*R)-1/(k_0**2*R**2))*g_R


    I = np.identity(3)
    G = (expr_1*RR_hat + expr_2*I).T

    return G

def make_detectors(N,sensor_radius,dimensions,uniform=True,plotting=False):
    if dimensions == 2:
        if uniform == True:
            sensor_phi = np.linspace(0,2*np.pi,N+1)[:-1] #Uniform distribution
        else:
            sensor_phi = np.random.random(N)*2*np.pi

        sensor_x = sensor_radius*np.cos(sensor_phi).reshape(N,1)
        sensor_y = sensor_radius*np.sin(sensor_phi).reshape(N,1)
        sensor_z = np.zeros_like(sensor_x)

        if plotting == True:
            plt.plot(sensor_x,sensor_y,'*')
            plt.show()

        sensors = np.append(np.append(sensor_x,sensor_y,axis=1),sensor_z,axis=1)

    elif dimensions == 3:
        if uniform == True:
            sensor_x = []
            sensor_y = []
            sensor_z = []
            phi = np.pi * (3. - np.sqrt(5.))  # golden angle in radians

            for i in range(N):
                y = (1 - (i / float(N - 1)) * 2)  # y goes from 1 to -1
                radius = np.sqrt(1 - y * y)  # radius at y

                theta = phi * i  # golden angle increment

                x = np.cos(theta) * radius
                z = np.sin(theta) * radius

                sensor_x.append(x)
                sensor_y.append(y)
                sensor_z.append(z)

            sensor_x = np.array(sensor_x)*sensor_radius
            sensor_x = sensor_x.reshape(N,1)
            sensor_y = np.array(sensor_y)*sensor_radius
            sensor_y = sensor_y.reshape(N,1)
            sensor_z = np.array(sensor_z)*sensor_radius
            sensor_z = sensor_z.reshape(N,1)

        else:
            sensor_theta = (np.random.random(N))*np.pi
            sensor_phi = np.random.random(N)*2*np.pi

            sensor_x = (sensor_radius*np.sin(sensor_theta)*np.cos(sensor_phi)).reshape(N,1)
            sensor_y = (sensor_radius*np.sin(sensor_theta)*np.sin(sensor_phi)).reshape(N,1)
            sensor_z = (sensor_radius*np.cos(sensor_theta)).reshape(N,1)

        if plotting == True:
            fig = plt.figure()
            ax = fig.add_subplot(111, projection='3d')
            ax.scatter(sensor_x,sensor_y,sensor_z,c='r',marker='o')
            plt.show()

        sensors = np.append(np.append(sensor_x,sensor_y,axis=1),sensor_z,axis=1)

    # sensor_locations = [sensor_theta,sensor_phi,sensor_radius,sensor_x,sensor_y,sensor_z]
    sensor_locations = [sensor_radius,sensor_x,sensor_y,sensor_z]
    return sensors, sensor_locations

def detector_field(detectors,dipole_pos,wl,polarization,uniform=True):
    N_sensors = detectors.shape[0]
    G = np.zeros((N_sensors,3,3),dtype=np.complex128)
    for i,detector in enumerate(detectors):
        G[i,:,:] = single_point_dyadicgreens(dipole_pos,detector,wl)


    Ex_sensor = np.zeros(N_sensors,dtype=np.complex128)
    Ey_sensor = np.zeros(N_sensors,dtype=np.complex128)
    Ez_sensor = np.zeros(N_sensors,dtype=np.complex128)

    for i,element in enumerate(polarization):
        Ex_sensor += element*G[:,0,i]
        Ey_sensor += element*G[:,1,i]
        Ez_sensor += element*G[:,2,i]

    E = [Ex_sensor,Ey_sensor,Ez_sensor]

    return E

def reconstruction(N,dimensions,FoV,sensor_locations,E_sensors):
    eps_0 = 8.8541878128e-12
    mu_0 = 4*np.pi*10**-7
    c_0 = 1/np.sqrt(eps_0*mu_0)
    wl = 561e-9 #Wavelength in meter
    freq = c_0/wl
    k_0 = 2*np.pi*freq*np.sqrt(eps_0*mu_0)

    x = np.linspace(-FoV/2,FoV/2,N)
    y = np.linspace(-FoV/2,FoV/2,N)
    if dimensions == 2:
        z = 0
    elif dimensions == 3:
        z = np.linspace(-FoV/2,FoV/2,N)

    xx,yy,zz = np.meshgrid(x,y,z)
    rho_im = np.sqrt(xx**2+yy**2)

    Ex_im = np.zeros(xx.shape,dtype=np.complex128)
    Ey_im = np.zeros(xx.shape,dtype=np.complex128)
    Ez_im = np.zeros(xx.shape,dtype=np.complex128)

    # sensor_theta,sensor_phi,sensor_radius, sensor_x, sensor_y, sensor_z = sensor_locations
    sensor_radius, sensor_x, sensor_y, sensor_z = sensor_locations
    Ex_sensor,Ey_sensor,Ez_sensor = E_sensors
    for i in range(Ex_sensor.shape[0]):
        # if dimensions == 2:
        #     k_x = k_0*np.cos(sensor_phi[i])
        #     k_y = k_0*np.sin(sensor_phi[i])
        #     k_z = 0
        #     Ex_im += np.conj(Ex_sensor[i]*np.exp(1j*(k_x*xx+k_y*yy+k_z*zz)))
        #     Ey_im += np.conj(Ey_sensor[i]*np.exp(1j*(k_x*xx+k_y*yy+k_z*zz)))
        #     Ez_im += np.conj(Ez_sensor[i]*np.exp(1j*(k_x*xx+k_y*yy+k_z*zz)))
        # elif dimensions == 3:
        #     k_x = k_0*np.sin(sensor_theta[i])*np.cos(sensor_phi[i])
        #     k_y = k_0*np.sin(sensor_theta[i])*np.sin(sensor_phi[i])
        #     k_z = k_0*np.cos(sensor_theta[i])
        #     Ex_im += np.conj(Ex_sensor[i]*np.exp(1j*(k_x*xx+k_y*yy+k_z*zz)))
        #     Ey_im += np.conj(Ey_sensor[i]*np.exp(1j*(k_x*xx+k_y*yy+k_z*zz)))
        #     Ez_im += np.conj(Ez_sensor[i]*np.exp(1j*(k_x*xx+k_y*yy+k_z*zz)))
        k_x = k_0*sensor_x[i,0]/sensor_radius
        k_y = k_0*sensor_y[i,0]/sensor_radius
        k_z = k_0*sensor_z[i,0]/sensor_radius
        Ex_im += np.conj(Ex_sensor[i]*np.exp(1j*(k_x*xx+k_y*yy+k_z*zz)))
        Ey_im += np.conj(Ey_sensor[i]*np.exp(1j*(k_x*xx+k_y*yy+k_z*zz)))
        Ez_im += np.conj(Ez_sensor[i]*np.exp(1j*(k_x*xx+k_y*yy+k_z*zz)))

    I = np.sqrt((np.abs(Ex_im)**2)+(np.abs(Ey_im)**2)+(np.abs(Ez_im)**2))

    return I
