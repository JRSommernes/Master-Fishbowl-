import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from dyadicgreens import *
from PIL import Image
import os

def plot_dyadicgreens():
    position = np.array([0,0,0]) #Offsett from center in x, y, and z direction set in microns
    N = 201 #Sample points in x, y, and z
    # wl = 561e-9
    wl = 690e-9 #Wavelength in meter
    FoV = 4*wl

    G = dyadicgreens(position, FoV, N, wl)

    I = np.sqrt(np.sum((np.abs(G))**2,axis=0)) #Her e det feil

    im = I[0,:,:,N//2].real

    plt.imshow(im)
    plt.show()


def detectors_dyadicgreens_2D(N_sensors, N_resampling, wl, dipole_pos, dimensions=3, uniform=True, plot_detector_location=False, saveimage=True):
    FoV = 4*wl
    sensor_radius = 10*wl
    pol = np.array([[1,0,0],[0,0,1]])

    if len(dipole_pos) == 2:
        distanse = np.sqrt((dipole_pos[1,0]-dipole_pos[0,0])**2+(dipole_pos[1,1]-dipole_pos[0,1])**2+(dipole_pos[1,2]-dipole_pos[0,2])**2)
        distanse /= wl

    detectors = make_detectors(N_sensors,sensor_radius,dimensions,uniform,plot_detector_location)
    E_x_tot = np.zeros(N_sensors,dtype=np.complex128)
    E_y_tot = np.zeros(N_sensors,dtype=np.complex128)
    E_z_tot = np.zeros(N_sensors,dtype=np.complex128)
    for i in range(len(dipole_pos)):
        dipole = dipole_pos[i]
        polarization = pol[i]
        E_sensors = detector_field(detectors,dipole,wl,polarization)
        E_x,E_y,E_z = E_sensors
        E_x_tot += E_x
        E_y_tot += E_y
        E_z_tot += E_z
    E_tot = [E_x_tot,E_y_tot,E_z_tot]
    I = reconstruction(N_resampling,dimensions,FoV,detectors,sensor_radius,E_tot)

    if saveimage == True:
        names = os.listdir('images')
        for i in range(1,1000):
            name = '{}_dipoles__{}_sensors_{}_wl_distance_{}'.format(len(dipole_pos),N_sensors,round(distanse,2),i)
            if name not in names:
                print(name)
                break
        os.mkdir('images/'+name)
        for i in range(N_resampling):
            im = Image.fromarray(I[:,:,i].astype(np.float64))
            im.save('images/'+name+'/{}.tiff'.format(i))

    if dimensions == 2:
        plt.imshow(I[:,:,0],extent=(-wl*2,wl*2,wl*2,-wl*2))
        plt.xlabel('x')
        plt.ylabel('y')
        plt.colorbar()
        for dipole in dipole_pos:
            plt.scatter(dipole[0],dipole[1],color='r')
        plt.show()
    elif dimensions == 3:
        plt.imshow(I[:,:,N_resampling//2],extent=(-FoV/2,FoV/2,FoV/2,-FoV/2))
        plt.xlabel('x')
        plt.ylabel('y')
        plt.colorbar()
        for dipole in dipole_pos:
            plt.scatter(dipole[0],dipole[1],color='r')
        if saveimage == True:
            plt.savefig('images/grount_truth/'+name+'.tiff')
        else:
            plt.show()
        plt.cla()   # Clear axis
        plt.clf()   # Clear figure


N_sensors = 100
N_resampling = 101
wl = 690e-9

dist = np.linspace(0.3*wl,0.6*wl,12)


# for num in dist:
#     x = num/2
#     dipole_pos = np.array([[-x,0,0],[x,0,0]])
#     detectors_dyadicgreens_2D(N_sensors, N_resampling, wl, dipole_pos)

dipole_pos = np.array([[-0.3*wl,0.7*wl,0],[0.7*wl,0.7*wl,0]])
detectors_dyadicgreens_2D(N_sensors, N_resampling, wl, dipole_pos)

# dipole_set = np.array([[[wl*0.1,0,0],[wl*1.3,0,0]],
#                         [[wl*0.1,0,0],[wl*1.1,0,0]],
#                         [[wl*0.1,0,0],[wl*0.9,0,0]],
#                         [[wl*0.1,0,0],[wl*0.7,0,0]],
#                         [[wl*0.1,0,0],[wl*0.5,0,0]]])
# dipole_pos = np.array([[-wl*1.3,0,0],[wl*0.9,0,0]])

# for dipole_pos in dipole_set:
#     detectors_dyadicgreens_2D(N_sensors, N_resampling, wl, dipole_pos)
