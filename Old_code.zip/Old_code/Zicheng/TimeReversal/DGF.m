% Simulating time reversal 
close all;
clear all;

eps0 = 8.8541878128e-12;
mu0 = 4*pi*10^-7;
c0 = 1/sqrt(eps0*mu0);
lambda0 = 561e-9;  % 400 to 700 nm
freq = c0/lambda0;
k0 = 2*pi*freq*sqrt(eps0*mu0);
omega = 2*pi*freq;

% position of dipole 
posDipole = [0,0,0];
% position of observation
vec_xObs = (-2:0.01:2)*lambda0;
vec_yObs = (-2:0.01:2)*lambda0;
zObs = 0;

Ex_xpol = zeros(length(vec_yObs),length(vec_xObs));
Ey_xpol = zeros(length(vec_yObs),length(vec_xObs));
Ez_xpol = zeros(length(vec_yObs),length(vec_xObs));
for ixObs = 1:length(vec_xObs)
    xObs = vec_xObs(ixObs);
    for iyObs = 1:length(vec_yObs)
        yObs = vec_yObs(iyObs);
        posObs = [xObs,yObs,zObs];
        solG = homogeneousDyadicGreen(k0,posObs-posDipole);
        Ex_xpol(iyObs,ixObs) = solG(1,1);
        Ey_xpol(iyObs,ixObs) = solG(2,1);
        Ez_xpol(iyObs,ixObs) = solG(3,1);
    end
end
ampMap = sqrt((abs(Ex_xpol).^2)+(abs(Ey_xpol).^2)+(abs(Ez_xpol).^2));
disp(ampMap(1,1))

[mat_xObs,mat_yObs] = meshgrid(vec_xObs,vec_yObs);
mat_rhoObs = sqrt(abs(mat_xObs).^2 + abs(mat_yObs).^2);

ampMap(mat_rhoObs(:)< 0.2*lambda0) = nan;

figure(1)
imagesc(vec_xObs/lambda0,vec_yObs/lambda0,log10(ampMap))

% add time domain information
vec_t = (0.1:0.1:5)/freq;
figure(2)
hold on;
for it = 1:length(vec_t)
    iEx_xpol = Ex_xpol*exp(-1i*omega*vec_t(it));
    iEy_xpol = Ey_xpol*exp(-1i*omega*vec_t(it));
    iEz_xpol = Ez_xpol*exp(-1i*omega*vec_t(it));
    iEx_xpol = real(iEx_xpol);
    iEy_xpol = real(iEy_xpol);
    iEz_xpol = real(iEz_xpol);
    ampMap = (abs(iEx_xpol).^2)+(abs(iEy_xpol).^2)+(abs(iEz_xpol).^2);
    ampMap(mat_rhoObs(:)< 0.2*lambda0) = nan;
    imagesc(vec_xObs/lambda0,vec_yObs/lambda0,log10(ampMap))
    axis([-2,2,-2,2])
    pause(0.1);
end


