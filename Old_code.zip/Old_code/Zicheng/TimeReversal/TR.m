% Simulating time reversal 
close all;
clear all;

eps0 = 8.8541878128e-12;
mu0 = 4*pi*10^-7;
c0 = 1/sqrt(eps0*mu0);
lambda0 = 561e-9;  % 400 to 700 nm
freq = c0/lambda0;
k0 = 2*pi*freq*sqrt(eps0*mu0);
omega = 2*pi*freq;

% position of dipole 
posDipole = [-0.5*lambda0,-0.5*lambda0,0];
% position of sensor position
rhoSensor = 10*lambda0;
nSensor = 50;
eqAngle = 2*pi/nSensor;
angSensor = 0:eqAngle:(2*pi-eqAngle);
vec_xSensor = rhoSensor*cos(angSensor);
vec_ySensor = rhoSensor*sin(angSensor);
zSensor = 0;

Ex_Sensor = zeros(length(vec_ySensor),1);
Ey_Sensor = zeros(length(vec_ySensor),1);
Ez_Sensor = zeros(length(vec_ySensor),1);
for iSensor = 1:length(vec_ySensor)
    xSensor = vec_xSensor(iSensor);
    ySensor = vec_ySensor(iSensor);
    posSensor = [xSensor,ySensor,zSensor];
    solG = homogeneousDyadicGreen(k0,posSensor-posDipole);
    Ex_Sensor(iSensor) = solG(1,1);
    Ey_Sensor(iSensor) = solG(2,1);
    Ez_Sensor(iSensor) = solG(3,1);
end

vec_xObs = (-2:0.01:2)*lambda0;
vec_yObs = (-2:0.01:2)*lambda0;
zObs = 0;
[mat_xObs,mat_yObs] = meshgrid(vec_xObs,vec_yObs);
mat_rhoObs = sqrt(abs(mat_xObs).^2 + abs(mat_yObs).^2);

figure(1)
hold on;
iEx_xpol = zeros(length(vec_yObs),length(vec_xObs));
iEy_xpol = zeros(length(vec_yObs),length(vec_xObs));
iEz_xpol = zeros(length(vec_yObs),length(vec_xObs));
for iSensor = 1:length(vec_ySensor)
    kx = k0*cos(angSensor(iSensor));
    ky = k0*sin(angSensor(iSensor));
    iEx_xpol = iEx_xpol + conj(Ex_Sensor(iSensor)*exp(1i*(kx*mat_xObs+ky*mat_yObs)));
    iEy_xpol = iEy_xpol + conj(Ey_Sensor(iSensor)*exp(1i*(kx*mat_xObs+ky*mat_yObs)));
    iEz_xpol = iEz_xpol + conj(Ez_Sensor(iSensor)*exp(1i*(kx*mat_xObs+ky*mat_yObs)));
end
ampMap = sqrt((abs(iEx_xpol).^2)+(abs(iEy_xpol).^2)+(abs(iEz_xpol).^2));
imagesc(vec_xObs/lambda0,vec_yObs/lambda0,log10(ampMap))
axis([-2,2,-2,2])



