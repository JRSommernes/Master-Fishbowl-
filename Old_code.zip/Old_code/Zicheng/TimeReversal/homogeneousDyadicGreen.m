function refG = homogeneousDyadicGreen(k,dr)

abs_dr = norm(dr);
uni_dr = dr/abs_dr;
g = exp(1i*k*abs_dr)/(4*pi*abs_dr);
mat_dr = uni_dr.' * uni_dr;
%Rett til g ivertfall
refG = g*((3/(k^2*abs_dr^2)-3i/(k*abs_dr)-1)*mat_dr+(1+1i/(k*abs_dr)-1/(k^2*abs_dr^2))*eye(3));