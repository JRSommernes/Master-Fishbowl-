function EMConfig = config


eps0 = 8.8541878128e-12;  % permittivity of air
mu0 = 4*pi*10^-7; % permeability of air

% parameter about wave
c0 = 1/sqrt(eps0*mu0); % wave speed in air
lambda0 = 561e-9;  % wavelength (400 to 700 nm)
freq = c0/lambda0; % frequency
k0 = 2*pi*freq*sqrt(eps0*mu0); % wavenumber in air

% parameter about objective region (above substrate)
mur_obj = 1; % relative permeability
n_obj = 1.33; % refractive index of water 1.33
epsr_obj = n_obj^2/mur_obj; % relative permittivity
k_obj = k0 * n_obj;

% parameter about substrate
mur_sub = 1;
n_sub = 4.3; % refractive index of crown glass 1.52, silicon 4.3 
epsr_sub = n_sub^2/mur_sub;
k_sub = k0 * n_sub;
zInterface_sub = -30e-9; % z coordinate of substrate interface

% parameter about camera region
mur_cam = 1;
n_cam = 1;
epsr_cam = n_cam^2/mur_cam;
k_cam = k0 * n_cam;


EMConfig.freq = freq;
EMConfig.mu0 = mu0;
EMConfig.k_obj = k_obj;
EMConfig.k_sub = k_sub;
EMConfig.k_cam = k_cam;
EMConfig.epsr_obj = epsr_obj;
EMConfig.mur_obj = mur_obj;
EMConfig.epsr_sub = epsr_sub;
EMConfig.mur_sub = mur_sub;
EMConfig.epsr_cam = epsr_cam;
EMConfig.mur_cam = mur_cam;
EMConfig.n_obj = n_obj;
EMConfig.n_sub = n_sub;
EMConfig.n_cam = n_cam;
EMConfig.lambda0 = lambda0;

% parameter for lenses
f_cam = 16e-2;
% f_obj = 1e-2;
EMConfig.latMag = 60;
f_obj = f_cam/(EMConfig.latMag/(EMConfig.n_obj/EMConfig.n_cam));
EMConfig.zInterface_sub = zInterface_sub;
EMConfig.f_obj = f_obj;
EMConfig.f_cam = f_cam;
NA = 1.2; % numerical aperture
theta_max = asin(NA/n_obj); % angular semiaperture
% NA = n_obj*sin(theta_max);
EMConfig.theta_max = theta_max;
EMConfig.NA = NA;
EMConfig.latMag = (n_obj/n_cam)*(f_cam/f_obj);
EMConfig.lonMag = (n_cam/n_obj)*(EMConfig.latMag^2);



