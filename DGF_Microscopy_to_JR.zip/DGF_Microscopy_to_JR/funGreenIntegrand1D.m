function [solG,alpha] = funGreenIntegrand1D(EMConfig,pos_cam,pos_obj_d)

x_cam = pos_cam(1);
y_cam = pos_cam(2);
z_cam = pos_cam(3);
x_obj_d = pos_obj_d(1);
y_obj_d = pos_obj_d(2);
z_obj_d = pos_obj_d(3);

k_cam = EMConfig.k_cam;
k_obj = EMConfig.k_obj;
f_cam = EMConfig.f_cam;
f_obj = EMConfig.f_obj;
n_cam = EMConfig.n_cam;
n_obj = EMConfig.n_obj;
k_sub = EMConfig.k_sub;

alpha = k_cam*exp(1i*(k_obj*f_obj+k_cam*f_cam))/(8i*pi);
alpha  = alpha * f_obj/f_cam;
alpha  = alpha * sqrt(n_obj/n_cam);

theta_max = EMConfig.theta_max;
zInterface_sub = EMConfig.zInterface_sub;

kz_obj = @(theta_obj)k_obj*cos(theta_obj);
kz_sub = @(theta_obj)sqrt(k_sub^2-(k_obj*sin(theta_obj)).^2);
RTE = @(theta_obj)(kz_obj(theta_obj)/EMConfig.mur_obj-kz_sub(theta_obj)/EMConfig.mur_sub)./(kz_obj(theta_obj)/EMConfig.mur_obj+kz_sub(theta_obj)/EMConfig.mur_sub).*exp(-2i*kz_obj(theta_obj)*zInterface_sub);
Q = @(theta_obj) (kz_obj(theta_obj)*k_sub^2*EMConfig.mur_obj)./(kz_sub(theta_obj)*k_obj^2*EMConfig.mur_sub);
RTM = @(theta_obj) (Q(theta_obj)-1).*exp(-2i*kz_obj(theta_obj)*zInterface_sub)./(Q(theta_obj)+1);
cosTheta_cam = @(theta_obj) sqrt(1-((f_obj/f_cam)^2)*(sin(theta_obj).^2));
sinTheta_cam = @(theta_obj) f_obj*sin(theta_obj)/f_cam;
rho_x = @(theta_obj) k_cam*sinTheta_cam(theta_obj)*x_cam-k_obj*sin(theta_obj)*x_obj_d;
rho_y = @(theta_obj) k_cam*sinTheta_cam(theta_obj)*y_cam-k_obj*sin(theta_obj)*y_obj_d;
rho = @(theta_obj) sqrt(rho_y(theta_obj).^2+rho_x(theta_obj).^2);
psi = @(theta_obj) atan2(rho_y(theta_obj),rho_x(theta_obj)); % psi \in [-pi, pi]
Zz = @(theta_obj) k_cam*cosTheta_cam(theta_obj)*z_cam-k_obj*cos(theta_obj)*z_obj_d;
Z = @(theta_obj) k_cam*cosTheta_cam(theta_obj)*z_cam+k_obj*cos(theta_obj)*z_obj_d;

fxx1 = @(theta_obj) (exp(1i*Zz(theta_obj))+RTE(theta_obj).*exp(1i*Z(theta_obj))+cosTheta_cam(theta_obj).*cos(theta_obj).*(exp(1i*Zz(theta_obj))-RTM(theta_obj).*exp(1i*Z(theta_obj))))...
    .*besselj(0,rho(theta_obj)).*sqrt(cos(theta_obj)./cosTheta_cam(theta_obj)).*sin(theta_obj);
Ixx1 =  integral(fxx1,0,theta_max); 
fxx2 = @(theta_obj) (exp(1i*Zz(theta_obj))+RTE(theta_obj).*exp(1i*Z(theta_obj))-cosTheta_cam(theta_obj).*cos(theta_obj).*(exp(1i*Zz(theta_obj))-RTM(theta_obj).*exp(1i*Z(theta_obj))))...
    .*besselj(2,rho(theta_obj)).*cos(2*psi(theta_obj)).*sqrt(cos(theta_obj)./cosTheta_cam(theta_obj)).*sin(theta_obj);
Ixx2 =  integral(fxx2,0,theta_max); 
Ixx = Ixx1 + Ixx2;
Iyy = Ixx1 - Ixx2;
fxy = @(theta_obj) (exp(1i*Zz(theta_obj))+RTE(theta_obj).*exp(1i*Z(theta_obj))-cosTheta_cam(theta_obj).*cos(theta_obj).*(exp(1i*Zz(theta_obj))-RTM(theta_obj).*exp(1i*Z(theta_obj))))...
    .*besselj(2,rho(theta_obj)).*sin(2*psi(theta_obj)).*sqrt(cos(theta_obj)./cosTheta_cam(theta_obj)).*sin(theta_obj);
Ixy =  integral(fxy,0,theta_max); 
Iyx = Ixy;
fxz = @(theta_obj) -2i*cosTheta_cam(theta_obj).*sin(theta_obj).*(exp(1i*Zz(theta_obj))+RTM(theta_obj).*exp(1i*Z(theta_obj)))...
    .*besselj(1,rho(theta_obj)).*cos(psi(theta_obj)).*sqrt(cos(theta_obj)./cosTheta_cam(theta_obj)).*sin(theta_obj);
Ixz =  integral(fxz,0,theta_max);
fyz = @(theta_obj) -2i*cosTheta_cam(theta_obj).*sin(theta_obj).*(exp(1i*Zz(theta_obj))+RTM(theta_obj).*exp(1i*Z(theta_obj)))...
    .*besselj(1,rho(theta_obj)).*sin(psi(theta_obj)).*sqrt(cos(theta_obj)./cosTheta_cam(theta_obj)).*sin(theta_obj);
Iyz =  integral(fyz,0,theta_max);
fzx = @(theta_obj) 2i*sinTheta_cam(theta_obj).*cos(theta_obj).*(exp(1i*Zz(theta_obj))-RTM(theta_obj).*exp(1i*Z(theta_obj)))...
    .*besselj(1,rho(theta_obj)).*cos(psi(theta_obj)).*sqrt(cos(theta_obj)./cosTheta_cam(theta_obj)).*sin(theta_obj);
Izx =  integral(fzx,0,theta_max);
fzy = @(theta_obj) 2i*sinTheta_cam(theta_obj).*cos(theta_obj).*(exp(1i*Zz(theta_obj))-RTM(theta_obj)).*exp(1i*Z(theta_obj))...
    .*besselj(1,rho(theta_obj)).*sin(psi(theta_obj)).*sqrt(cos(theta_obj)./cosTheta_cam(theta_obj)).*sin(theta_obj);
Izy =  integral(fzy,0,theta_max); 
fzz = @(theta_obj) -2*sinTheta_cam(theta_obj).*sin(theta_obj).*(exp(1i*Zz(theta_obj))+RTM(theta_obj)).*exp(1i*Z(theta_obj))...
    .*besselj(0,rho(theta_obj)).*sqrt(cos(theta_obj)./cosTheta_cam(theta_obj)).*sin(theta_obj);
Izz =  integral(fzz,0,theta_max); 

solG = alpha*[Ixx,Ixy,Ixz;Iyx,Iyy,Iyz;Izx,Izy,Izz];

end