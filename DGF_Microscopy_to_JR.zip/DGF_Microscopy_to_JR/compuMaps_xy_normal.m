% Code to calculate the dyadic Green's function for microscopy where dipole
% is located above a half apce and the wave propagate through object and
% cam lenses
% Zicheng Liu, April 16, 2020, zicheng_liu@hotmail.com

clear all
close all

EMConfig = config;

% position of 1st dipole 
xobj_d1 = 0.4*EMConfig.lambda0;
yobj_d1 = 0.4*EMConfig.lambda0;
zobj_d1 = 0.4*EMConfig.lambda0;

% position of 2nd dipole 
xobj_d2 = -0.4*EMConfig.lambda0;
yobj_d2 = 0.4*EMConfig.lambda0;
zobj_d2 = 0.4*EMConfig.lambda0;
posobj_d1 = [xobj_d1,yobj_d1,zobj_d1];
posobj_d2 = [xobj_d2,yobj_d2,zobj_d2];

% position of camera sensors 
zo_cam =0;
vecxo_cam = (-3:0.1:3)*EMConfig.latMag*EMConfig.lambda0;
vecyo_cam = (-3:0.1:3)*EMConfig.latMag*EMConfig.lambda0;
E_xcom_xpol_d1 = zeros(length(vecyo_cam),length(vecxo_cam)); % x-component of electric field due to x-polarized dipole
E_ycom_xpol_d1 = zeros(length(vecyo_cam),length(vecxo_cam));
E_zcom_xpol_d1 = zeros(length(vecyo_cam),length(vecxo_cam));
E_xcom_zpol_d1 = zeros(length(vecyo_cam),length(vecxo_cam));
E_ycom_zpol_d1 = zeros(length(vecyo_cam),length(vecxo_cam));
E_zcom_zpol_d1 = zeros(length(vecyo_cam),length(vecxo_cam));
E_xcom_xpol_d2 = zeros(length(vecyo_cam),length(vecxo_cam));
E_ycom_xpol_d2 = zeros(length(vecyo_cam),length(vecxo_cam));
E_zcom_xpol_d2 = zeros(length(vecyo_cam),length(vecxo_cam));
E_xcom_zpol_d2 = zeros(length(vecyo_cam),length(vecxo_cam));
E_ycom_zpol_d2 = zeros(length(vecyo_cam),length(vecxo_cam));
E_zcom_zpol_d2 = zeros(length(vecyo_cam),length(vecxo_cam));
for iy = 1:length(vecyo_cam)
    fprintf('%d-th row...\n',iy)
    yo_cam =  vecyo_cam(iy);
    for ix = 1:length(vecxo_cam)
        xo_cam =  vecxo_cam(ix);
        pos_cam = [xo_cam,yo_cam,zo_cam]; % position of camera sensor
        solG1 = funGreenIntegrand1D(EMConfig,pos_cam,posobj_d1);
        E_xcom_xpol_d1(iy,ix) = solG1(1,1);
        E_ycom_xpol_d1(iy,ix) = solG1(2,1);
        E_zcom_xpol_d1(iy,ix) = solG1(3,1);
        E_xcom_zpol_d1(iy,ix) = solG1(1,3);
        E_ycom_zpol_d1(iy,ix) = solG1(2,3);
        E_zcom_zpol_d1(iy,ix) = solG1(3,3);
        
        solG2 = funGreenIntegrand1D(EMConfig,pos_cam,posobj_d2);
        E_xcom_xpol_d2(iy,ix) = solG2(1,1);
        E_ycom_xpol_d2(iy,ix) = solG2(2,1);
        E_zcom_xpol_d2(iy,ix) = solG2(3,1);
        E_xcom_zpol_d2(iy,ix) = solG2(1,3);
        E_ycom_zpol_d2(iy,ix) = solG2(2,3);
        E_zcom_zpol_d2(iy,ix) = solG2(3,3);
    end
end
intensity_xpol = (abs(E_xcom_xpol_d1+E_xcom_xpol_d2).^2)+(abs(E_ycom_xpol_d1+E_ycom_xpol_d2).^2)+(abs(E_zcom_xpol_d1+E_zcom_xpol_d2).^2);
intensity_zpol = (abs(E_xcom_zpol_d1+E_xcom_zpol_d2).^2)+(abs(E_ycom_zpol_d1+E_ycom_zpol_d2).^2)+(abs(E_zcom_zpol_d1+E_zcom_zpol_d2).^2);

vecxo = vecxo_cam/(EMConfig.latMag*EMConfig.lambda0);
vecyo = vecyo_cam/(EMConfig.latMag*EMConfig.lambda0);

figure
subplot(3,3,1)
imagesc(vecxo,vecyo,abs(E_xcom_xpol_d1).^2)
colorbar
subplot(3,3,2)
imagesc(vecxo,vecyo,abs(E_ycom_xpol_d1).^2)
colorbar
subplot(3,3,3)
imagesc(vecxo,vecyo,abs(E_zcom_xpol_d1).^2)
colorbar
subplot(3,3,4)
imagesc(vecxo,vecyo,abs(E_xcom_xpol_d2).^2)
colorbar
subplot(3,3,5)
imagesc(vecxo,vecyo,abs(E_ycom_xpol_d2).^2)
colorbar
subplot(3,3,6)
imagesc(vecxo,vecyo,abs(E_zcom_xpol_d2).^2)
colorbar
subplot(3,3,8)
imagesc(vecxo,vecyo,intensity_xpol)
colorbar

figure
subplot(3,3,1)
imagesc(vecxo,vecyo,abs(E_xcom_zpol_d1).^2)
colorbar
subplot(3,3,2)
imagesc(vecxo,vecyo,abs(E_ycom_zpol_d1).^2)
colorbar
subplot(3,3,3)
imagesc(vecxo,vecyo,abs(E_zcom_zpol_d1).^2)
colorbar
subplot(3,3,4)
imagesc(vecxo,vecyo,abs(E_xcom_zpol_d2).^2)
colorbar
subplot(3,3,5)
imagesc(vecxo,vecyo,abs(E_ycom_zpol_d2).^2)
colorbar
subplot(3,3,6)
imagesc(vecxo,vecyo,abs(E_zcom_zpol_d2).^2)
colorbar
subplot(3,3,8)
imagesc(vecxo,vecyo,intensity_zpol)
colorbar
